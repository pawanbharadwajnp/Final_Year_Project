<!DOCTYPE html>
<html lang="en">
<head>
    <title>PG Finder</title>
    <link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Fruktur&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body >
    <div class="main" style="	background-image: url('back.png'); background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;" >
        <div class="navbar">
            <div class="icon">
                <h2 class="logo"> 			<img src="1.jfif" alt="logo" style=" width:50%;height:75%;   border-radius: 50%;" ></img> <br>PG Finder</h2>
            </div>
			<div class="menu">
                <ul>
                    <li><a href="./user intetrface/user/login/login.php">USER</a></li>
                    <li><a href="./user intetrface/admin/login/login.php">CLIENTS</a></li>
                </ul>
            </div>

            
        </div>
		&nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp;
		<script>
document.getElementById('button123').addEventListener('click', function (e) {
  console.log(1);
})
</script>
		<br><br><br><br><br><br><br>
		<center>
		            <div >
                <h1 style="color:#FF8621;">About Project</h1>
<div id="button123"  style="   width:40%;     text-align: justify; text-justify:center" >
                <p style="color:white;font-size:20px;">The application helps users to easily search for nearby Paying Guests (PG) allowing them to book for PG facility.
				<br>The inmates are allowed to provide rating and comments. Outsiders have facility to blog
									and go through the details of the PG, if a suitable PG is availlable
									he can book the PG.<br>
									The Client (PG Manager) has the facility to register to the application
									so that details of the PG is available for others.
				</p>
				</div>
				
				<br><br><br>
				
				
                <h2 style="color:#FF8621;" >About Us</h2>
                <p style="color:white;"> 
				The Guide for this website   <br>
				•Prof. Uma Paare  <br> <br> <br> 
				<b>The developers are</b> <br>
				•Pawan Bharadwaj N P (4VP18CS059)<br>
				•Sandeep Kumar T (4VP18CS075)<br>
				•Shravan A (4VP18CS083)<br>
				•Abishek Nayak  (4VP18CS094)<br>
	
					
					
				</p>

            </div>
			</center>
    </div>
	<center style="background-color:#153445">


                <h1 style="color:#C52DC0;">Contact Us</h1>


		&nbsp &nbsp &nbsp;
		<a href="https://twitter.com/Pawan91137470/">
			<button class="btn22">

				<i class="fa fa-twitter fa-2x"></i>
		</a>
		</button>
		
		&nbsp &nbsp;
		<a href="https://twitter.com/Shravan54124742/">
			<button class="btn22">

				<i class="fa fa-twitter fa-2x"></i>
		</a>
		</button>
		
		&nbsp &nbsp;
		<a href="https://twitter.com/Abhishe94047281?t=cx-tCw9tO5aR2Pl_ehi4YA&s=09">
			<button class="btn22">

				<i class="fa fa-twitter fa-2x"></i>
		</a>
		</button>
		
		&nbsp &nbsp;
		<a href="https://mobile.twitter.com/Sandeep66493409">
			<button class="btn22">

				<i class="fa fa-twitter fa-2x"></i>
		</a>
		</button>
		



		&nbsp &nbsp &nbsp;

		<a href="https://github.com/pawanbharadwajnp/Final_Year_Project.git" src="" alt="">
			<button class="btn22">

				<i class="fa fa-github fa-2x"></i>
		</a>
		</button>


		<style>
			.btn22 {
				border-radius: 50%;
				width: 3rem;
				height: 3rem;


			}

			.fot {
				padding-right: 1015px;

			}

			a:visited {
				text-decoration: none;
				color: black;

			}

			.fr {
				color: white;
			}
		</style>
	</center>
	
</body>
</html>